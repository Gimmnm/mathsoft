class Cooperate():
    ''' Cooperate will always cooperate. '''
    def step(self, history, round):
        action = 1

        return action