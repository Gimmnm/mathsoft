class Defect():
    ''' Defect will always defect. '''
    def step(self, history, round):
        action = 0

        return action