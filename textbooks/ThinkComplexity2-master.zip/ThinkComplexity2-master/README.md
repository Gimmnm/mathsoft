ThinkComplexity
===============
2nd Edition

Code for Allen Downey's book Think Complexity, 2nd edition.

PDF and HTML versions available from http://greenteapress.com/wp/think-complexity/

The first edition, published by O'Reilly Media, is available from http://greenteapress.com/complexity/index.html
